param(
    [switch]$Elevated,
    [switch]$ForceElevate
)

# ============================================================
#  AION2 Timer - minimal local web server
#
#  This file is intentionally pure ASCII.
#  Windows PowerShell 5.1 decodes .ps1 files using the system
#  ANSI code page when there is no BOM, which corrupts UTF-8
#  text and breaks parsing. Keeping it ASCII avoids that
#  entirely, on any system locale.
#
#  About privileges: this script normally does NOT need admin.
#    - Uses TcpListener, not HttpListener. HttpListener needs a
#      URL ACL reservation and fails for non-admin users;
#      a raw TCP socket bound to 127.0.0.1 needs no privilege.
#    - Binds loopback only, so Windows Firewall never prompts.
#    - Execution policy is handled per-invocation by the .bat.
#  It therefore elevates ONLY if binding is actually denied.
# ============================================================

$ErrorActionPreference = 'Stop'

$portStart  = 8777
$portTries  = 12
$page       = 'boss-timer.html'
$root       = $PSScriptRoot
$scriptPath = $MyInvocation.MyCommand.Path

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Invoke-Elevate([string]$reason) {
    if ($Elevated) { return $false }   # already elevated and still failing
    Write-Host ''
    Write-Host "  Elevation needed: $reason" -ForegroundColor Yellow
    Write-Host '  Requesting admin rights, please click Yes on the UAC prompt...' -ForegroundColor Yellow
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @(
            '-NoProfile', '-ExecutionPolicy', 'Bypass',
            '-File', "`"$scriptPath`"", '-Elevated'
        )
        return $true
    } catch {
        Write-Host '  Elevation was cancelled or blocked by policy.' -ForegroundColor Red
        return $false
    }
}

# When running elevated, open the browser as the normal user.
# Notification permission is stored per browser profile, so an
# admin-launched browser would use a different context and lose it.
# Handing the URL to explorer.exe de-elevates the launch.
function Open-Url([string]$url) {
    if (Test-Admin) { Start-Process 'explorer.exe' -ArgumentList $url }
    else            { Start-Process $url }
}

$mime = @{
    '.html' = 'text/html; charset=utf-8'
    '.htm'  = 'text/html; charset=utf-8'
    '.js'   = 'text/javascript; charset=utf-8'
    '.css'  = 'text/css; charset=utf-8'
    '.json' = 'application/json; charset=utf-8'
    '.png'  = 'image/png'
    '.jpg'  = 'image/jpeg'
    '.jpeg' = 'image/jpeg'
    '.gif'  = 'image/gif'
    '.svg'  = 'image/svg+xml'
    '.ico'  = 'image/x-icon'
    '.webp' = 'image/webp'
}

if (-not (Test-Path (Join-Path $root $page))) {
    Write-Host ''
    Write-Host "  [X] $page not found." -ForegroundColor Red
    Write-Host "      Put $page in the same folder as this script."
    Write-Host ''
    Read-Host '  Press Enter to close'
    exit
}

if ($ForceElevate -and -not (Test-Admin)) {
    if (Invoke-Elevate 'requested with -ForceElevate') { exit }
}

# --- Start listening. Busy port: step to the next one.
#     Access denied: that is a real privilege problem, so elevate. ---
$listener = $null
$port     = $null

for ($i = 0; $i -lt $portTries; $i++) {
    $try = $portStart + $i
    try {
        $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $try)
        $l.Start()
        $listener = $l
        $port     = $try
        break
    } catch [System.Net.Sockets.SocketException] {
        if ($_.Exception.SocketErrorCode -eq 'AccessDenied') {
            if (Invoke-Elevate "binding port $try was denied") { exit }
            Write-Host ''
            Write-Host '  [X] Could not obtain rights. Server not started.' -ForegroundColor Red
            Read-Host '  Press Enter to close'
            exit
        }
        continue
    }
}

if (-not $listener) {
    $last = $portStart + $portTries - 1
    Write-Host ''
    Write-Host "  [X] Ports $portStart-$last are all in use." -ForegroundColor Red
    Write-Host '      Close whatever is using them, or edit $portStart in this file.'
    Write-Host ''
    Read-Host '  Press Enter to close'
    exit
}

$url  = "http://localhost:$port/$page"
if (Test-Admin) { $mode = 'Administrator' } else { $mode = 'Standard user (no elevation needed)' }

Write-Host ''
Write-Host '  AION2 Timer' -ForegroundColor Cyan
Write-Host '  =========================================='
Write-Host "  Folder : $root"
Write-Host "  URL    : $url"
Write-Host "  Rights : $mode"
Write-Host ''
Write-Host '  The browser opens automatically.' -ForegroundColor Green
Write-Host '  KEEP THIS WINDOW OPEN. Closing it stops the server.' -ForegroundColor Yellow
Write-Host '  =========================================='
Write-Host ''

Open-Url $url

while ($true) {
    $client = $null
    try {
        $client = $listener.AcceptTcpClient()
        $client.ReceiveTimeout = 3000
        $client.SendTimeout    = 20000

        $ns = $client.GetStream()
        $sr = New-Object System.IO.StreamReader($ns, [System.Text.Encoding]::ASCII)

        $requestLine = $sr.ReadLine()
        if ([string]::IsNullOrWhiteSpace($requestLine)) { continue }

        do { $h = $sr.ReadLine() } while ($null -ne $h -and $h -ne '')

        $target = ($requestLine -split ' ')[1]
        $target = ($target -split '\?')[0]
        $target = [System.Uri]::UnescapeDataString($target)
        if ($target -eq '/') { $target = "/$page" }

        $rel  = $target.TrimStart('/') -replace '/', '\'
        $full = [System.IO.Path]::GetFullPath((Join-Path $root $rel))

        # Path traversal guard: only serve files under this folder
        if ($full.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase) -and
            (Test-Path $full -PathType Leaf)) {

            $bytes = [System.IO.File]::ReadAllBytes($full)
            $ext   = [System.IO.Path]::GetExtension($full).ToLower()
            $ct    = $mime[$ext]
            if (-not $ct) { $ct = 'application/octet-stream' }

            $head = "HTTP/1.1 200 OK`r`n" +
                    "Content-Type: $ct`r`n" +
                    "Content-Length: $($bytes.Length)`r`n" +
                    "Cache-Control: no-store`r`n" +
                    "Connection: close`r`n`r`n"
            Write-Host ("  200  " + $target)
        } else {
            $bytes = [System.Text.Encoding]::UTF8.GetBytes('404 Not Found')
            $head  = "HTTP/1.1 404 Not Found`r`n" +
                     "Content-Type: text/plain; charset=utf-8`r`n" +
                     "Content-Length: $($bytes.Length)`r`n" +
                     "Connection: close`r`n`r`n"
            Write-Host ("  404  " + $target) -ForegroundColor DarkGray
        }

        $hb = [System.Text.Encoding]::ASCII.GetBytes($head)
        $ns.Write($hb, 0, $hb.Length)
        $ns.Write($bytes, 0, $bytes.Length)
        $ns.Flush()
    }
    catch {
        # Browsers open speculative connections and drop them; ignore.
    }
    finally {
        if ($client) { $client.Close() }
    }
}
