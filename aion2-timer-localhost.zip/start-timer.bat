@echo off
chcp 65001 >nul
cd /d "%~dp0"
title AION2 Timer

if not exist "%~dp0serve.ps1" (
    echo.
    echo   [X] serve.ps1 not found.
    echo       Keep start-timer.bat, serve.ps1 and boss-timer.html together.
    echo.
    pause
    goto :eof
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0serve.ps1"

echo.
echo   Server stopped.
pause
